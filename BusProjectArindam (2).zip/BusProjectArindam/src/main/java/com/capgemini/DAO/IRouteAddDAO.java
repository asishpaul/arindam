package com.capgemini.DAO;

import com.capgemini.pojo.Routetable;

public interface IRouteAddDAO {
	public abstract Routetable addRoute(Routetable newroute);
}
