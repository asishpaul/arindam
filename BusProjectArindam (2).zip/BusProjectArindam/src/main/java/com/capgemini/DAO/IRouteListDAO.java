package com.capgemini.DAO;

import java.util.List;

import com.capgemini.pojo.Routetable;

public interface IRouteListDAO {
	public abstract List<Routetable> listAllRoutes();
}
