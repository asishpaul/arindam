package com.capgemini.service;

import com.capgemini.pojo.LoginPOJO;

public interface ILoginService {
	public abstract boolean checkUser(LoginPOJO loginPOJO);
}
