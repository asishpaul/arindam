package com.capgemini.service;

import java.util.List;

import com.capgemini.pojo.Routetable;

public interface IRouteListService {
	
	public abstract List<Routetable> listAllRoutes();

}
