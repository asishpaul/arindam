package com.capgemini.LMS.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.LMS.bean.Users;
import com.capgemini.LMS.exception.LibraryException;
import com.capgemini.LMS.util.DBConnection;



public class LoginDaoImpl implements ILoginDao{


	@Override
	public List<Users> getallusers() throws LibraryException {

		List<Users> lst = new ArrayList<>();
		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();
				)
				{
			PreparedStatement statement1=connection.prepareStatement(QueryMapper.DISPLAY_USERS);
			ResultSet rs= statement1.executeQuery();
			while(rs.next())
			{
				Users user = new Users();
				user.setUserId(rs.getString(1));
				user.setUserName(rs.getString(2));
				user.setPassword(rs.getString(3));
				user.setEmailId(rs.getString(4));
				user.setLibrarian(rs.getBoolean(5));
				lst.add(user);
			}


				} catch (SQLException e) {
					e.printStackTrace();
				}
		return lst;


	}

	public Boolean validStudent(String userName, String password, int c) throws LibraryException {

		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();
				PreparedStatement pst=connection.prepareStatement(QueryMapper.DISPLAY_USERS);
				)
				{		
			ResultSet rs =pst.executeQuery();
			while(rs.next()) {
				if(rs.getString(2).compareTo(userName)==0 && rs.getString(3).compareTo(password)==0 && rs.getInt(5)==c)
				{
					return true;
				}					
			}

				} catch (SQLException e) {
					e.printStackTrace();
				}
		return false;
	}
	public Boolean validLibrarian(String userNameLib, String passwordLib, int c) throws LibraryException {
		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();
				)
				{
			PreparedStatement pst=connection.prepareStatement(QueryMapper.DISPLAY_USERS);
			ResultSet rs =pst.executeQuery();
			while(rs.next()) {
				if(rs.getString(2).equals(userNameLib) && rs.getString(3).equals(passwordLib)&& rs.getInt(5)==c)
				{
					return true;
				}
			}

				} catch (SQLException e) {
					e.printStackTrace();
				}
		return false;


	}

}
