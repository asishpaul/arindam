package com.capgemini.LMS.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.LMS.bean.BooksInventory;
import com.capgemini.LMS.util.DBConnection;


public class AddDeleteBookDaoImpl implements IAddDeleteBookDao {

	@Override
	public void addBook(BooksInventory booksInventory) {	

		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();)
				{
			PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.BOOK_INSERT);
			preparedStatement.setString(1, booksInventory.getBookId());
			preparedStatement.setString(2, booksInventory.getBookName());
			preparedStatement.setString(3, booksInventory.getAuthor1());
			preparedStatement.setString(4, booksInventory.getAuthor2());
			preparedStatement.setString(5, booksInventory.getPublisher());
			preparedStatement.setString(6, booksInventory.getYearOfPub());

			int row=preparedStatement.executeUpdate();

			if(row>0)
				System.out.println("Book has been added to the library!");

				} catch (SQLException e) {
					e.printStackTrace();
				}			

	}

	@Override
	public List<BooksInventory> getAllBooks() {

		List<BooksInventory> allBookList = new ArrayList<>();

		try(
				Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();
			)
			{
				PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.DISPLAY_BOOKS);
				ResultSet resultSet= preparedStatement.executeQuery();
			
				while(resultSet.next()){
				BooksInventory booksInventory = new BooksInventory();
				booksInventory.setBookId(resultSet.getString(1));
				booksInventory.setBookName(resultSet.getString(2));
				booksInventory.setAuthor1(resultSet.getString(3));
				booksInventory.setAuthor2(resultSet.getString(4));
				booksInventory.setPublisher(resultSet.getString(5));
				booksInventory.setYearOfPub(resultSet.getString(6));
				allBookList.add(booksInventory);
				}
				
			}catch (SQLException e){
					e.printStackTrace();
			}
		return allBookList;

	}


	public void deleteBook(String bookId) {
		
		try(
				Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();
				){
			PreparedStatement preparedStatement1=connection.prepareStatement(QueryMapper.DELETE_BOOK_FOREIGN_KEY_CHECK1);
			ResultSet resultSet1 =preparedStatement1.executeQuery();
			PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.DELETE_BOOK);
			preparedStatement.setString(1, bookId);
			int row = preparedStatement.executeUpdate();

			if(row<0)
			{
				System.out.println("Book has not been deleted");
			}
			else
			{
				System.out.println("Book has  been deleted");
			}


			PreparedStatement preparedStatement2=connection.prepareStatement(QueryMapper.DELETE_BOOK_FOREIGN_KEY_CHECK2);
			ResultSet resultSet2 =preparedStatement1.executeQuery();

		} catch (SQLException e) {

			e.printStackTrace();
		}



	}

}
