package com.capgemini.LMS.DAO;

import java.util.List;

import com.capgemini.LMS.bean.BooksInventory;
import com.capgemini.LMS.bean.BooksRegistration;
import com.capgemini.LMS.bean.Users;
import com.capgemini.LMS.exception.LibraryException;


public interface IRegistrationDao {
	
	public List<BooksRegistration> getRegistration(Users user, BooksInventory books)throws LibraryException;
	void doRegistration(BooksInventory books, Users user, BooksRegistration register)throws LibraryException;

}
