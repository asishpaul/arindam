package com.capgemini.LMS.DAO;

import java.util.List;

import com.capgemini.LMS.bean.BooksInventory;
import com.capgemini.LMS.exception.LibraryException;

public interface IAddDeleteBookDao {
	
	public void addBook(BooksInventory booksInventory)throws LibraryException;
	public List<BooksInventory> getAllBooks()throws LibraryException;
	public void deleteBook(String bookId)throws LibraryException;

}
