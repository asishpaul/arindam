package com.capgemini.LMS.DAO;

import java.util.List;

import com.capgemini.LMS.bean.Users;
import com.capgemini.LMS.exception.LibraryException;

public interface ILoginDao {
	
	public Boolean validStudent(String userName, String password, int c)throws LibraryException;
	public Boolean validLibrarian(String userNameLib, String passwordLib, int c)throws LibraryException;
	public List<Users> getallusers()throws LibraryException;
	

}
