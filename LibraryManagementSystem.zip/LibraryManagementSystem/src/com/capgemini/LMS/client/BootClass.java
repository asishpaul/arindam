package com.capgemini.LMS.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.LMS.bean.BooksInventory;
import com.capgemini.LMS.bean.BooksRegistration;
import com.capgemini.LMS.bean.BooksTransaction;
import com.capgemini.LMS.bean.Users;
import com.capgemini.LMS.exception.LibraryException;
import com.capgemini.LMS.service.AddDeleteBookServiceImpl;
import com.capgemini.LMS.service.IAddDeleteBookService;
import com.capgemini.LMS.service.ILoginService;
import com.capgemini.LMS.service.IRegistrationService;
import com.capgemini.LMS.service.ITransactionService;
import com.capgemini.LMS.service.LoginServiceImpl;
import com.capgemini.LMS.service.RegistrationServiceImpl;
import com.capgemini.LMS.service.TransactionServiceImpl;

public class BootClass {



	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args)  {
		ILoginService loginService = new LoginServiceImpl();
		Users users = new Users();
		IAddDeleteBookService addDeleteService = new AddDeleteBookServiceImpl();
		UserInteraction userInteraction = new UserInteraction();
		IRegistrationService regService = new RegistrationServiceImpl();
		ITransactionService tranService = new TransactionServiceImpl();
		 
		boolean stop = true;

		do {   

			// FRONT END //
			System.out.println("--------------------------------------------------------");
			System.out.println("\tWelcome to Library");
			System.out.println("--------------------------------------------------------");
			System.out.println("Enter Your Choice");
			System.out.println("1- Login as a student");
			System.out.println("2- Login as a librarian");
			System.out.println("3- Exit");

			System.out.println("-----------------------------------------\n");        


			int choice = 0;
			choice = scanner.nextInt();

			switch(choice)
			{ 
			case 1:
				System.out.println("\nEnter User Name: ");  
				String userName = scanner.next();
				System.out.println("\nEnter Password: ");
				String password = scanner.next();

				if (userName == null || password ==null){

					System.out.println("Sorry! You have missed information required");
					System.exit(0);
				} else
					try {
						if (loginService.validStudent(userName, password, 0))
						{                    
							do   
							{


								System.out.println("--------------------------------------------------------");
								System.out.println("\t  Welcome to Student's Portal");
								System.out.println("--------------------------------------------------------");
								System.out.println("Enter your Choice");
								System.out.println("1- List all books");
								System.out.println("2- Request a book to be issued");
								System.out.println("3- Check  request queue of a Book");                         
								System.out.println("4- Logout");
								System.out.println("-------------------------------------------------------");




								int ch = scanner.nextInt();

								List<BooksInventory> booksList = addDeleteService.getallbooks();
								List<Users> usersList =new ArrayList<>(); 
								usersList = loginService.getallusers();
								Users user =new Users();

								switch(ch)
								{
								case 1:
									userInteraction.printBooks(booksList);
									break;
								case 2:

									
									userInteraction.printBooks(booksList);
									List<Users> users1 = loginService.getallusers();
									BooksInventory selectedBook = userInteraction.findallbooks(booksList);

									if(selectedBook==null){
										System.out.println("Not a Valid Book");
									}
									else{

										user = userInteraction.getUser(userName, users1);
										regService.doRegistration(selectedBook, user, userInteraction.register(selectedBook, user));
									}

									break;
									
								case 3:

									List<BooksInventory> bookIns1 = addDeleteService.getallbooks();
									List<Users> users2 = loginService.getallusers();
									System.out.println("Enter User_Id");
									String user_id1 = scanner.next();
									System.out.println("Enter Book_Id");
									String book_id = scanner.next();
									selectedBook = userInteraction.getBook(book_id, bookIns1);
									user = userInteraction.getUser(user_id1, users2);
									List<BooksRegistration> bookregister = regService.getRegistration(user,selectedBook);
									userInteraction.printRegistrationRequest(bookregister);
									break;
								case 4:
									System.out.println("You have been logged out!!!");
									System.out.println("Do you want to login as another user? [true|false]");
									stop = scanner.nextBoolean();
									break;
								}
									
								}							
							while(stop);
						}
						else {
							System.out.println("No you are unauthorised to access");
							break;
						}
					} catch (LibraryException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				System.exit(0);


			case 2:
				System.out.println("\nEnter User Name: ");  
				String userNameLib = scanner.next();
				System.out.println("\nEnter Password: ");
				String passwordLib = scanner.next();

				if (userNameLib == null){

					System.out.println("Sorry! You have missed information required");
					System.exit(0);
				} else
					try {
						if (loginService.validLibrarian(userNameLib, passwordLib, 1))
						{
							do 
							{

								System.out.println("------------------------------------------------------------------");
								System.out.println("\t   Welcome to the Librarian's Portal");
								System.out.println("------------------------------------------------------------------");
								System.out.println("Enter your Choice");
								System.out.println("1- List all book");      
								System.out.println("2- Check requests of a book");                        
								System.out.println("3- Confirm request of a book"); 
								System.out.println("4- Do you want to add new book?");
								System.out.println("5- Do you want to remove book?");                       
								System.out.println("6- Logout");
								System.out.println("--------------------------------------------------------");

								BooksInventory book = new BooksInventory();
								List<Users> users4 = loginService.getallusers();
								Users user1 = new Users();
								BooksRegistration bookreg = new BooksRegistration();
								BooksTransaction booktrans = new BooksTransaction();
								int ch = scanner.nextInt();
								switch(ch)
								{
									case 1:
									List<BooksInventory> books = addDeleteService.getallbooks();
									userInteraction.printBooks(books);
									break;
									
								case 2:
									List<Users> users2 = loginService.getallusers();
									Users user = new Users();
									System.out.println("Enter User_Id");
									String user_id1 = scanner.next();
									user = userInteraction.getUser(user_id1, users2);

									List<BooksInventory> bookIns2 = addDeleteService.getallbooks();
									System.out.println("Enter Book_Id");
									String book_id = scanner.next();
									book = userInteraction.getBook(book_id, bookIns2);

									List<BooksRegistration> bookregister = regService.getRegistration(user, book);
									userInteraction.printRegistrationRequest(bookregister);
									break;
								case 3:

									List<Users> users5 = loginService.getallusers();
									Users user2 = new Users();
									BooksRegistration bookreg1 = new BooksRegistration();
									System.out.println("Enter User_Id");
									String userId4 = scanner.next();
									user1 = userInteraction.getUser(userId4, users5);

									List<BooksInventory> bookIns4 = addDeleteService.getallbooks();
									System.out.println("Enter Book_Id");
									String bookid1 = scanner.next();
									book = userInteraction.getBook(bookid1, bookIns4);

									List<BooksRegistration> registers2 = regService.getRegistration(user1, book);
									userInteraction.printRegistrationRequest(registers2);
									System.out.println("Enter the registrationId for whom you want to issue a book");
									String regId2 = scanner.next();
									bookreg = userInteraction.getRegister(regId2, registers2);
									tranService.doTransaction(userInteraction.transaction(bookreg), bookreg);
									break;
								case 4:
									addDeleteService.addBook(userInteraction.getDetailsofBook());
									break;
								case 5:
									List<BooksInventory> books1 = addDeleteService.getallbooks();
									userInteraction.printBooks(books1);
									System.out.println("Enter the Book Id to be deleted");
									String bookId =scanner.next();
									addDeleteService.deleteBook(bookId);
									break;
								case 6:

									System.out.println("You have been logged out!!!");
									System.out.println("Do you want to login as another user? [true|false]");
									stop = scanner.nextBoolean();
									break;
								}

							               
						
						}while(stop);}
		
						else {
							System.out.println("No you are unauthorised to access!!");
							break;
						}
					} catch (LibraryException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}



			case 3:
				stop = false; 
				break;
			
		
}}while(stop);
		
	
	}
}





