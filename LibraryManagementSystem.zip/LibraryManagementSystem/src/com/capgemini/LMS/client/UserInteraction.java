package com.capgemini.LMS.client;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.capgemini.LMS.bean.BooksInventory;
import com.capgemini.LMS.bean.BooksRegistration;
import com.capgemini.LMS.bean.BooksTransaction;
import com.capgemini.LMS.bean.Users;

public class UserInteraction {

	Scanner scanner = new Scanner(System.in);
	BooksInventory book = new BooksInventory();
	BooksRegistration register = new BooksRegistration();
	BooksTransaction trans = new BooksTransaction();
	Users user = new Users();


	public void printBooks(List<BooksInventory> books)
	{
		System.out.println("BookID\tBookName\t"
				+ "Author1\t\tAuthor2\t  Publisher\t  YearofPublisher");
		System.out.println("-----------------------------------------------------------------");

		for(BooksInventory book:books)
		{
			System.out.println(book.getBookId()+"\t   "+book.getBookName()+"\t\t    "+
					book.getAuthor1()+"\t   "+book.getAuthor2()+"\t   "+book.getPublisher()+"\t   "+
					book.getYearOfPub());
		}
	}



	public void printRegistrationRequest(List<BooksRegistration> registers)
	{
		System.out.println("RegistrationID\t  RegistrationDate\t");
		System.out.println("-----------------------------------------------------------------");

		for(BooksRegistration register:registers)
		{
			System.out.println(register.getRegistrationId()+"\t   "+register.getRegistrationDate());
		}
	}


	public void printTransactions(List<BooksTransaction> transactions)
	{
		System.out.println("TransactionID\tIssueDate\t"
				+ "ReturnDate\tFine");
		System.out.println("-----------------------------------------------------------------");

		for(BooksTransaction transaction:transactions)
		{
			System.out.println(transaction.getTransactionId()+"\t   "+transaction.getIssueDate());
		}
	}

	public BooksInventory findallbooks(List<BooksInventory> books)
	{


		System.out.println("Enter your Book_Id");
		String Book_Id;
		Book_Id=scanner.next();

		for(BooksInventory book : books)
		{

			if(Book_Id.equals(book.getBookId()))
			{
				return book;
			}

		}

		return null;
	}


	public BooksInventory getBook(String book_id, List<BooksInventory> books)
	{
		for(BooksInventory book:books)
		{
			if(book.getBookId().equals("book_id"));
			return book;
		}
		System.out.println("Enter valid Book ID!");
		return null;
	}

	public Users getUser(String userName, List<Users> users)
	{
		for(Users user:users)
		{
			if(user.getUserName().equals(userName));
			return user;
		}
		System.out.println("Enter valid User ID!");
		return null;
	}

	public BooksRegistration getRegister(String user_id, List<BooksRegistration> registers)
	{
		for(BooksRegistration register:registers)
		{
			if(register.getRegistrationId().equals("user_id"));
			return register;
		}
		System.out.println("Enter valid Registration ID!");
		return null;
	}


	public BooksTransaction getTransaction(String transact_id, List<BooksTransaction> transactions)
	{
		for(BooksTransaction transaction:transactions)
		{
			if(transaction.getRegistrationId().equals("transact_id"));
			return transaction;
		}
		System.out.println("Enter valid Transaction ID!");
		return null;
	}

	public BooksRegistration register(BooksInventory bookId , Users userId)
	{	
		BooksInventory bookInvet =new BooksInventory();
		System.out.println("You can register by filling details");
		System.out.println("Enter your registration_Id");
		String reg_id = scanner.next();
		register.setRegistrationId(reg_id);
		register.setBookId(bookId);
		register.setUserId(userId);
		LocalDate reg_date = LocalDate.now();
		System.out.println("Your registration date"+reg_date);
		register.setRegistrationDate(reg_date);


		return register;
	}



	public BooksInventory getDetailsofBook()
	{
		System.out.println("Enter Book Id");
		String book_id = scanner.nextLine();
		book.setBookId(book_id);
		System.out.println("Enter Book Name");
		String book_name = scanner.nextLine();
		book.setBookName(book_name);
		System.out.println("Enter Book Author 1");
		String author1 = scanner.nextLine();
		book.setAuthor1(author1);
		System.out.println("Enter Book Author 2");
		String author2 = scanner.nextLine();
		book.setAuthor2(author2);
		System.out.println("Enter Book Publisher");
		String publisher = scanner.nextLine();
		book.setPublisher(publisher);
		System.out.println("Enter Book Year of Publishing");
		String yearofpub = scanner.nextLine();
		book.setYearOfPub(yearofpub);

		return book;

	}

	public BooksTransaction transaction(BooksRegistration bookreg)
	{	
		BooksRegistration registerissue =new BooksRegistration();
		System.out.println("You can do transaction by entering transaction_id");
		System.out.println("Enter your Transaction_Id");
		String trans_id = scanner.next();
		trans.setTransactionId(trans_id);
		trans.setRegistrationId(bookreg);
		LocalDate issueDate = LocalDate.now();
		System.out.println("Your issue date is"+issueDate);
		trans.setIssueDate(issueDate);		
		return trans;
	}
}



