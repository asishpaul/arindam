package com.capgemini.LMS.bean;

import java.time.LocalDate;

public class BooksTransaction {

	private String transactionId;
	private BooksRegistration registrationId;
	private LocalDate issueDate;
	
	public BooksTransaction() {
		
	}
	public BooksTransaction(String transactionId, BooksRegistration registrationId, LocalDate issueDate) {
		super();
		this.transactionId = transactionId;
		this.registrationId = registrationId;
		this.issueDate = issueDate;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public BooksRegistration getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(BooksRegistration registrationId) {
		this.registrationId = registrationId;
	}
	public LocalDate getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}
	
	@Override
	public String toString() {
		return "BooksTransaction [transactionId=" + transactionId
				+ ", registrationId=" + registrationId + ", issueDate="
				+ issueDate + "]";
	}	
	
}
