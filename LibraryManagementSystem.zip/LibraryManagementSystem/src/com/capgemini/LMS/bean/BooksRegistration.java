package com.capgemini.LMS.bean;

import java.time.LocalDate;

public class BooksRegistration {

	private String registrationId;
	private BooksInventory bookId;
	private Users userId;
	private LocalDate registrationDate;

	public BooksRegistration() {

	}
	public BooksRegistration(String registrationId, BooksInventory bookId, Users userId, LocalDate registrationDate) {
		super();
		this.registrationId = registrationId;
		this.bookId = bookId;
		this.userId = userId;
		this.registrationDate = registrationDate;
	}
	
	public String getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(String registrationId) {
		this.registrationId = registrationId;
	}
	public BooksInventory getBookId() {
		return bookId;
	}
	public void setBookId(BooksInventory bookId) {
		this.bookId = bookId;
	}
	public Users getUserId() {
		return userId;
	}
	public void setUserId(Users userId) {
		this.userId = userId;
	}
	public LocalDate getRegistrationDate() {
		return registrationDate;
	}
	public void setRegistrationDate(LocalDate registrationDate) {
		this.registrationDate = registrationDate;
	}
	@Override
	public String toString() {
		return "BooksRegistration [registrationId=" + registrationId + ", bookId=" + bookId + ", userId=" + userId
				+ ", registrationDate=" + registrationDate + "]";
	}


}
