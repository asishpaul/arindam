package com.capgemini.LMS.service;

import java.util.List;

import com.capgemini.LMS.bean.Users;
import com.capgemini.LMS.exception.LibraryException;


public interface ILoginService {
	
	public Boolean validStudent(String userName, String password, int c)throws LibraryException;
	public Boolean validLibrarian(String userNameLib, String passwordLib, int c)throws LibraryException;
	public List<Users> getallusers()throws LibraryException;
}
