package com.capgemini.LMS.service;

import java.util.List;

import com.capgemini.LMS.bean.BooksRegistration;
import com.capgemini.LMS.bean.BooksTransaction;
import com.capgemini.LMS.exception.LibraryException;

public interface ITransactionService {

	public void doTransaction(BooksTransaction bookstransaction, BooksRegistration bookreg)throws LibraryException;
	

	public List<BooksTransaction> getAllTransaction(BooksRegistration regid)throws LibraryException;

	
	
}
