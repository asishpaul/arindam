package com.capgemini.LMS.service;

import java.util.List;

import com.capgemini.LMS.DAO.ITransactionDao;
import com.capgemini.LMS.DAO.TransactionDaoImpl;
import com.capgemini.LMS.bean.BooksRegistration;
import com.capgemini.LMS.bean.BooksTransaction;
import com.capgemini.LMS.exception.LibraryException;

public class TransactionServiceImpl implements ITransactionService {

	
	ITransactionDao transactiondao = new TransactionDaoImpl(); 
	@Override
	public void doTransaction(BooksTransaction bookstransaction, BooksRegistration regid) throws LibraryException {
	
		transactiondao.doTransaction(bookstransaction,regid);
		
		
	}

	@Override
	public List<BooksTransaction> getAllTransaction(BooksRegistration regid) throws LibraryException {
		// TODO Auto-generated method stub
		return transactiondao.getAllTransaction(regid);
	}

	

	

}
