package com.capgemini.LMS.service;

import java.util.List;

import com.capgemini.LMS.bean.BooksInventory;
import com.capgemini.LMS.bean.BooksRegistration;
import com.capgemini.LMS.bean.Users;
import com.capgemini.LMS.exception.LibraryException;

public interface IRegistrationService {
	
	public List<BooksRegistration> getRegistration(Users user , BooksInventory books)throws LibraryException;
	public void doRegistration(BooksInventory books, Users user, BooksRegistration register)throws LibraryException;

}
