package org.lib.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.lib.bean.BooksInventory;
import org.lib.bean.BooksRegistration;
import org.lib.bean.Users;

public class RegistrationDaoImpl implements IRegistrationDao{
	
	
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/LMS", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			
			//e.printStackTrace();
		}
		
		return null;
		
	}

	@Override
	public List<BooksRegistration> getRegistration(Users user , BooksInventory books) {
		List<BooksRegistration> registers =new ArrayList<>();
		String str="select * from BooksRegistration where user_id="+user.getUser_id()+";";
		String str1 ="select * from users";
		String str2 = "select * from booksinventory";
		try(Connection connection=getDbConnection())
		{
			BooksInventory book = new BooksInventory();
			Users userid = new Users();
			PreparedStatement statement=connection.prepareStatement(str);
			PreparedStatement statement1=connection.prepareStatement(str1);
			PreparedStatement statement2=connection.prepareStatement(str2);
			
			ResultSet rs= statement.executeQuery();
			ResultSet rs1= statement1.executeQuery();
			ResultSet rs2= statement2.executeQuery();
			
			
			while(rs2.next())
			{
				
				book.setBook_id(rs2.getString(1));
				
			}
			
			while(rs1.next())
			{
				userid.setUser_id(rs1.getString(1));
			}
			
			while(rs.next())
			{
				BooksRegistration reg =new BooksRegistration();
				reg.setRegistration_id(rs.getString(1));
				reg.setBook_id(book);
				reg.setUser_id(userid);
				reg.setRegistrationdate(rs.getDate(4).toLocalDate());
				registers.add(reg);	
			
			}
		}	catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return registers;
	}

	@Override
	public void doRegistration(BooksInventory books, Users user, BooksRegistration register) {
		String sql="insert into BooksRegistration values(?,?,?,?);";
		
		try(Connection connection=getDbConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			
			statement.setString(1, register.getRegistration_id());
			statement.setString(2, register.getBook_id().getBook_id());
			statement.setString(3, register.getUser_id().getUser_id());
			statement.setDate(4, java.sql.Date.valueOf(register.getRegistrationdate()));
			
			int row=statement.executeUpdate();
			
			if(row>0)
				System.out.println("Your book has been registerd and forwarded to librarian!");
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


}
