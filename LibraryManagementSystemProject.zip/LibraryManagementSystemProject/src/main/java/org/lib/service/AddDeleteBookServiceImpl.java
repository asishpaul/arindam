package org.lib.service;

import java.util.List;
import java.util.Set;

import org.lib.bean.BooksInventory;
import org.lib.dao.AddDeleteBookDaoImpl;
import org.lib.dao.IAddDeleteBookDao;


public class AddDeleteBookServiceImpl implements IAddDeleteBookService {
	
	 IAddDeleteBookDao adddelete= new AddDeleteBookDaoImpl();

	@Override
	public void addBook(BooksInventory booksinventory) {
		adddelete.addBook(booksinventory);
		
	}

	@Override
	public List<BooksInventory> getallbooks() {
		// TODO Auto-generated method stub
		return adddelete.getallbooks();
	}

	@Override
	public void deleteBook(String bookId) {

		adddelete.deleteBook(bookId);
		
	}

	

}
