package org.lib.service;

import java.util.List;
import java.util.Set;

import org.lib.bean.BooksInventory;
import org.lib.bean.BooksRegistration;
import org.lib.bean.Users;

public interface IRegistrationService {
	
	public List<BooksRegistration> getRegistration(Users user , BooksInventory books);
	public void doRegistration(BooksInventory books, Users user, BooksRegistration register);

}
