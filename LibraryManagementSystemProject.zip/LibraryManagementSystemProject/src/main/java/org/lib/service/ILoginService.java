package org.lib.service;

import java.util.List;
import org.lib.bean.Users;


public interface ILoginService {
	
	public boolean validStudent(String userName, String password, int c);
	public boolean validLibrarian(String userNameLib, String passwordLib, int c);
	public List<Users> getallusers();
}
