package org.lib.service;

import java.util.List;
import java.util.Set;

import org.lib.bean.BooksInventory;
import org.lib.bean.BooksRegistration;
import org.lib.bean.Users;
import org.lib.dao.IRegistrationDao;
import org.lib.dao.RegistrationDaoImpl;

public class RegistrationServiceImpl implements IRegistrationService{

	
	IRegistrationDao regdao = new RegistrationDaoImpl();
	@Override
	public List<BooksRegistration> getRegistration(Users user, BooksInventory books) {
		// TODO Auto-generated method stub
		return regdao.getRegistration(user, books);
	}

	@Override
	public void doRegistration(BooksInventory books, Users user, BooksRegistration register) {
		regdao.doRegistration(books, user, register);
		
	}

}
